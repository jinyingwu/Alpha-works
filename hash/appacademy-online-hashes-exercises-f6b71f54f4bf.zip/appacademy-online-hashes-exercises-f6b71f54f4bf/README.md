# Enumerables Exercises

In this project you will practice working with ruby hashes.
Fill in each of the method bodies. Instructions for each method are in the
comments.
Run the specs to test your work:

```bash
  bundle install
  bundle exec rspec
```
